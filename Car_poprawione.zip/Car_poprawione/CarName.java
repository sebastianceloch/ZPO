package Car_poprawione;

public interface CarName {
    void showCarName();
}
