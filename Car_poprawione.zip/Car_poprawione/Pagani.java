package Car_poprawione;

public class Pagani implements CarName{
    @Override
    public void showCarName() {
        System.out.println("Pagani sportscar");
    }
}
