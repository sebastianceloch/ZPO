package Car_poprawione;

public class Fiat implements CarName{
    @Override
    public void showCarName() {
        System.out.println("Fiat car");
    }

}
