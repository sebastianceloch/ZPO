package Car_poprawione;

public class Peugeot implements CarName{

    @Override
    public void showCarName() {
        System.out.println("Peugeot nice car");
    }
}
