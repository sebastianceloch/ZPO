package Car_poprawione;

public class FastCar implements CarSpeed{
    @Override
    public int getMaxSpeed() {
        return 300;
    }
}
