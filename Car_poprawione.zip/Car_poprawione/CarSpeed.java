package Car_poprawione;

public interface CarSpeed {
    int getMaxSpeed();
}
