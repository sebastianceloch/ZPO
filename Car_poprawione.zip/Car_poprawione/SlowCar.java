package Car_poprawione;

public class SlowCar implements CarSpeed{
    @Override
    public int getMaxSpeed() {
        return 100;
    }
}
